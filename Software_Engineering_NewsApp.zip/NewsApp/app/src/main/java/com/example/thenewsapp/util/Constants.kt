package com.example.thenewsapp.util

class Constants {

    companion object{

        const val API_KEY = "a7da184c721146c99aa97892e3bd305c"
        const val Base_url = "https://newsapi.org/"
        const val Search_news_time_delay = 500L // 500 ml second after search
        const val Query_page_size = 20 // number of articles in a page



    }

}